<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Student extends Model
{
    use SoftDeletes;
    
    //Table Mana yang boleh di isi//
    protected $fillable = ['nama', 'nim', 'email', 'jurusan'];
    //Table mana yang tidak boleh di isi//
    // protected $guarded = ['nama', 'nim', 'email', 'jurusan'];
}
